message = "JOIN TO OUR DC SERVER `25fpyrWcnhQ" -- spam text here CHANGE!

while true do
sendPacket(false, "action|input\n|text|"..message,2 )
sleep(4200)
end